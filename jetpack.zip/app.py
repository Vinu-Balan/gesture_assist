import time
import cv2
from flask import Flask, render_template,request, Response
from tester import default_detection
import json
#from tester import predicter

app = Flask(__name__)

state = "Stop detection"

@app.route('/')
def index():
    """home page."""
    return render_template('Homepage.html')

@app.route('/default_detection',methods=['GET', 'POST'])

def default_detect():
    """Default page"""
    statesInfo = {
    "state": "active"
}
    json_object = json.dumps(statesInfo, indent=4)
    with open("switchdata.json", "w") as outfile:
        outfile.write(json_object)
    return render_template('defaultDetection.html')
@app.route('/default_statesInfo/<string:statesInfo>',methods=['GET', 'POST'])
def get_statesInfo(statesInfo):
    statesInfo = json.loads(statesInfo)
    print(statesInfo['state'])
    json_object = json.dumps(statesInfo, indent=4)
    with open("switchdata.json", "w") as outfile:
        outfile.write(json_object)
    return "sucessful"
@app.route('/default__video_feed')
def default_video_feed():
    """Video streaming route. Put this in the src attribute of an img tag."""
    return Response(default_detection(),mimetype='multipart/x-mixed-replace; boundary=frame')

if __name__=='__main__':
    app.run(debug=True)
