import cv2
import mediapipe as mp
import time
from csv import writer
import json
import numpy as np
import pickle
import pyautogui
from math import hypot
from playsound import playsound

width,height = pyautogui.size()

def default_detection():
    cap = cv2.VideoCapture(0)

    # model_file_name = 'gesture_model.sav'
    # model = pickle.load(open(model_file_name, 'rb'))

    mpHands = mp.solutions.hands
    hands = mpHands.Hands(max_num_hands=1, min_detection_confidence=0.7)
    mpDraw = mp.solutions.drawing_utils

    sTime = time.time()

    class_names = {0: "gest1", 1: "gest2", 2: "gest3", 3: "gest4", 4: "gest5", 5: "gest6", 6: "gest7"}

    pivot_x = 0

    pivot_y = 0

    row_list = []
    power_seq = ""
    match_power_seq1 = "111211"
    match_power_seq1_alt = "121112"

    # line
    prev_len = 0
    cur_len = 0

    ges_1 = 0
    ges_2 = 0
    ges_3 = 0
    ges_4 = 0
    ges_5 = 0
    ges_6 = 0
    ges_7 = 0
    ges_8 = 0
    ges_9 = 0
    ges_10 = 0
    ges_11 = 0
    zoom_in =0
    zoom_out = 0

    f1_x, f1_y = 0, 0
    f2_x, f2_y = 0, 0

    proceed = True

    font = cv2.FONT_HERSHEY_SIMPLEX
    org = (185, 50)
    color = (0, 0, 255)
    while (cap.isOpened()):
        f = open('switchdata.json', "r")
        # Reading from file
        data = json.loads(f.read())
        if data['state']=='active':
            proceed = True
        else:
            proceed = False
        ret, img = cap.read()
        img = cv2.resize(img, (960, 540))
        x, y, c = img.shape
        t_elapsed = abs(sTime - time.time())

        # if t_elapsed>120:
        #     break
        cTime = time.time()
        #print(img.shape)

        imgRGB = cv2.cvtColor(img,cv2.COLOR_BGR2RGB)
        results = hands.process(imgRGB)
        if results.multi_hand_landmarks!=0:
            if results.multi_hand_landmarks:
                for handlms in results.multi_hand_landmarks:
                    for id,lms in enumerate(handlms.landmark):
                        #print(id,lms)
                        h,w,c = img.shape
                        #print(img.shape)
                        cx,cy = int(lms.x*w),int(lms.y*h)
                        if id == 0:
                            pivot_x = int(lms.x * x)
                            pivot_y = int(lms.y * y)
                            mpDraw.draw_landmarks(img, handlms, mpHands.HAND_CONNECTIONS)
                            row_list.append(pivot_x)
                            row_list.append(pivot_y)
                        else:
                            lmx = int(lms.x * x)
                            lmy = int(lms.y * y)
                            mpDraw.draw_landmarks(img, handlms, mpHands.HAND_CONNECTIONS)
                            row_list.append(pivot_x - lmx)
                            row_list.append(pivot_y - lmy)
                        if id==4:
                            f1_x = lms.x
                            f1_y = lms.y
                        if id==8:
                            f2_x = lms.x
                            f2_y = lms.y

                    break

                cv2.circle(img, (int(f1_x * w), int(f1_y * h)), 10, (225, 225, 0), cv2.FILLED)
                cv2.circle(img, (int(f2_x * w), int(f2_y * h)), 10, (225, 225, 0), cv2.FILLED)
                cv2.line(img,(int(f1_x * w), int(f1_y * h)),(int(f2_x * w), int(f2_y * h)),(225, 225, 0),10)
                length = hypot(f2_x-f1_x,f2_y-f1_y)
                #print(length)
                if length>0.12:
                    # pyautogui.mouseDown()
                    pyautogui.press('space')
                else:
                    # pyautogui.mouseUp()
                    pass
                # # Predict gesture
                # prediction = model.predict([row_list])
                # # print(prediction)
                # classID = np.argmax(prediction)
                # row_list=[]
                # # cv2.putText(img, str(prediction[0]), org, font, fontScale=1, thickness=2, color=color)
                # # print(prediction[0])
                # # SLiding bar
                # if prediction[0]==10 and proceed:
                #     cv2.circle(img, (int(f1_x * w), int(f1_y * h)), 10, (225, 225, 0), cv2.FILLED)
                #     cv2.circle(img, (int(f2_x * w), int(f2_y * h)), 10, (225, 225, 0), cv2.FILLED)
                #     cv2.line(img,(int(f1_x * w), int(f1_y * h)),(int(f2_x * w), int(f2_y * h)),(225, 225, 0),10)
                #     length = hypot(f2_x-f1_x,f2_y-f1_y)
                #     #print(length)
                #     if length>0.13:
                #         zoom_in+=1
                #         zoom_out=0
                #         # if zoom_in>5:
                #         #     pyautogui.hotkey('ctrl', '+')
                #         pyautogui.mouseDown()
                #
                #         # pyautogui.press('space')
                #         zoom_in = 0
                #     else:
                #         zoom_out+=1
                #         zoom_in=0
                #         # if zoom_out>5:
                #         # pyautogui.hotkey('ctrl', '-')\
                #         pyautogui.mouseUp()
                #         zoom_out = 0
                # # if prediction[0]==0 and proceed:
                # #     ges_1 += 1
                # #     if ges_1 > 12:
                # #         cv2.putText(img, 'Gesture 1', org, font, fontScale=1, thickness=2, color=color)
                # #         ges_1 = 0
                # #         zoom_in = 0
                # #         zoom_out = 0
                # #         pyautogui.hotkey('ctrl','c')
                # #         power_seq = ""
                # #         playsound('mixkit-long-pop-2358.wav')
                # # elif prediction[0]==1 and proceed:
                # #     ges_2 += 1
                # #     zoom_in = 0
                # #     zoom_out = 0
                # #     if ges_2 > 12:
                # #         cv2.putText(img, 'Gesture 2', org, font, fontScale=1, thickness=2, color=color)
                # #         pyautogui.hotkey('ctrl', 'v')
                # #         power_seq = ""
                # #         ges_2 = 0
                # # elif prediction[0]==2 and proceed:
                # #     ges_3 += 1
                # #     zoom_in = 0
                # #     zoom_out = 0
                # #     if ges_3 > 12:
                # #         cv2.putText(img, 'Gesture 3', org, font, fontScale=1, thickness=2, color=color)
                # #         pyautogui.hotkey('ctrl', 'x')
                # #         power_seq = ""
                # #         ges_3 = 0
                # # elif prediction[0]==3 and proceed:
                # #     ges_4 += 1
                # #     zoom_in = 0
                # #     zoom_out = 0
                # #     if ges_4 > 12:
                # #         cv2.putText(img, 'Gesture 4', org, font, fontScale=1, thickness=2, color=color)
                # #         pyautogui.hotkey('winleft', 'shift','s')
                # #         power_seq = ""
                # #         ges_4 = 0
                # # elif prediction[0]==4 and proceed:
                # #     ges_5 += 1
                # #     zoom_in = 0
                # #     zoom_out = 0
                # #     if ges_5 > 12:
                # #         cv2.putText(img, 'Gesture 5', org, font, fontScale=1, thickness=2, color=color)
                # #         pyautogui.hotkey('ctrl', 'o')
                # #         power_seq = ""
                # #         ges_5 = 0
                # # elif prediction[0]==5 and proceed:
                # #     ges_6 += 1
                # #     zoom_in = 0
                # #     zoom_out = 0
                # #     if ges_6 > 12:
                # #         cv2.putText(img, 'Gesture 6', org, font, fontScale=1, thickness=2, color=color)
                # #         pyautogui.hotkey('ctrl', 'z')
                # #         power_seq = ""
                # #         ges_6 = 0
                # # elif prediction[0]==6 and proceed:
                # #     ges_7 += 1
                # #     zoom_in = 0
                # #     zoom_out = 0
                # #     if ges_7 > 12:
                # #         cv2.putText(img, 'Gesture 7', org, font, fontScale=1, thickness=2, color=color)
                # #         pyautogui.hotkey('ctrl', 'w')
                # #         power_seq = ""
                # #         ges_7 = 0
                # # elif prediction[0]==7 and proceed:
                # #     ges_8 += 1
                # #     zoom_in = 0
                # #     zoom_out = 0
                # #     if ges_8 > 12:
                # #         cv2.putText(img, 'Gesture 8', org, font, fontScale=1, thickness=2, color=color)
                # #         pyautogui.hotkey('ctrl', 's')
                # #         power_seq = ""
                # #         ges_8 = 0
                # # elif prediction[0]==8 and proceed:
                # #     ges_9 += 1
                # #     zoom_in = 0
                # #     zoom_out = 0
                # #     if ges_9 > 12:
                # #         cv2.putText(img, 'Gesture 9', org, font, fontScale=1, thickness=2, color=color)
                # #         pyautogui.hotkey('enter')
                # #         power_seq = ""
                # #         ges_9 = 0
                # # elif prediction[0]==9 and proceed:
                # #     ges_10 += 1
                # #     zoom_in = 0
                # #     zoom_out = 0
                # #     if ges_10 > 12:
                # #         cv2.putText(img, 'Gesture 10', org, font, fontScale=1, thickness=2, color=color)
                # #         pyautogui.hotkey('alt', 'f4')
                # #         power_seq = ""
                # #         ges_10 = 0
                # #

        #cv2.putText(img,str(int(fps)),(10,70),cv2.FONT_HERSHEY_DUPLEX,3,(225,0,225),3)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            # if the 'q' is pressed quit.'OxFF' is for 64 bit.[if waitKey==True] is condition
            break
        if ret == True:
            img = cv2.resize(img, (0, 0), fx=0.5, fy=0.5)
            frame = cv2.imencode('.jpg', img)[1].tobytes()
            yield (b'--frame\r\n'b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')
        else:
            break
    cap.release()
    cv2.destroyAllWindows()
